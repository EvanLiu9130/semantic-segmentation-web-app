import { GoogleGenAI, GenerateContentResponse } from '@google/genai';

// Assume process.env.API_KEY is available in the environment.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

function fileToGenerativePart(base64: string) {
  const match = base64.match(/^data:(.+);base64,(.+)$/);
  if (!match) {
    throw new Error("Invalid base64 string format");
  }
  const mimeType = match[1];
  const data = match[2];
  
  return {
    inlineData: {
      mimeType,
      data,
    },
  };
}

export const generateVisualQuery = async (prompt: string, imageBase64: string): Promise<string> => {
  const model = 'gemini-2.5-flash';

  try {
    const imagePart = fileToGenerativePart(imageBase64);
    
    const textPart = {
      text: prompt,
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: { parts: [textPart, imagePart] },
      config: {
        systemInstruction: "You are a helpful visual assistant. Please format your responses using Markdown for clarity and readability. Use headings, lists, and bold text where appropriate.",
      }
    });
    
    return response.text;
  } catch (error) {
    console.error('Error generating content from Gemini API:', error);
    if (error instanceof Error) {
        return `Error: ${error.message}`;
    }
    return 'An unexpected error occurred while querying the AI.';
  }
};