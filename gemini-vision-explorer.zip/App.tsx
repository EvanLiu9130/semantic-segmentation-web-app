
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { WebcamCapture } from './components/WebcamCapture';
import { UserInput } from './components/UserInput';
import { AIResponse } from './components/AIResponse';
import { Loader } from './components/Loader';
import { generateVisualQuery } from './services/geminiService';

const App: React.FC = () => {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState<string>('');
  const [aiResponse, setAiResponse] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleCapture = (imageBase64: string) => {
    setCapturedImage(imageBase64);
    setAiResponse('');
    setError(null);
  };

  const handleRetake = () => {
    setCapturedImage(null);
    setAiResponse('');
    setError(null);
    setPrompt('');
  };

  const handleSubmit = useCallback(async () => {
    if (!capturedImage || !prompt.trim()) {
      setError("Please capture an image and enter a prompt.");
      return;
    }

    setIsLoading(true);
    setAiResponse('');
    setError(null);

    try {
      const responseText = await generateVisualQuery(prompt, capturedImage);
      setAiResponse(responseText);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  }, [capturedImage, prompt]);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="flex flex-col gap-4">
            <h2 className="text-2xl font-bold text-cyan-400">1. Capture Image</h2>
            <div className="aspect-video w-full bg-slate-800 rounded-lg overflow-hidden shadow-lg border-2 border-slate-700 flex items-center justify-center">
              <WebcamCapture onCapture={handleCapture} capturedImage={capturedImage} />
            </div>
            {capturedImage && (
              <button
                onClick={handleRetake}
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-bold py-2 px-4 rounded-lg transition duration-300"
              >
                Retake Photo
              </button>
            )}
          </div>
          
          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-4">
              <h2 className="text-2xl font-bold text-cyan-400">2. Ask Gemini</h2>
              <UserInput
                prompt={prompt}
                setPrompt={setPrompt}
                onSubmit={handleSubmit}
                isLoading={isLoading}
                disabled={!capturedImage}
              />
            </div>
            
            <div className="flex flex-col gap-4">
              <h2 className="text-2xl font-bold text-cyan-400">3. AI Response</h2>
              <div className="bg-slate-800 p-4 rounded-lg shadow-lg min-h-[200px] border border-slate-700">
                {isLoading && <Loader />}
                {error && <div className="text-red-400">{error}</div>}
                {aiResponse && <AIResponse response={aiResponse} />}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
