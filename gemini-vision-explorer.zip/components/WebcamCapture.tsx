
import React, { useRef, useEffect, useState, useCallback } from 'react';

interface WebcamCaptureProps {
  onCapture: (imageBase64: string) => void;
  capturedImage: string | null;
}

export const WebcamCapture: React.FC<WebcamCaptureProps> = ({ onCapture, capturedImage }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);

  useEffect(() => {
    const enableStream = async () => {
      if (capturedImage) return;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: {
                facingMode: 'environment',
                width: { ideal: 1280 },
                height: { ideal: 720 }
            }
        });
        setStream(stream);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Error accessing webcam: ", err);
        setError("Could not access the camera. Please check permissions.");
      }
    };

    if (!stream) {
        enableStream();
    }
    
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [capturedImage]);

  const handleCanPlay = () => {
    setIsCameraReady(true);
  };

  const handleCaptureClick = useCallback(() => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext('2d');
      if(context){
        context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        onCapture(dataUrl);

        // Stop the stream after capture
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
      }
    }
  }, [onCapture, stream]);

  if (capturedImage) {
    return <img src={capturedImage} alt="Captured" className="w-full h-full object-contain" />;
  }

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-black">
      {error && <div className="text-red-400 p-4 text-center">{error}</div>}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className={`w-full h-full object-contain transition-opacity duration-500 ${isCameraReady ? 'opacity-100' : 'opacity-0'}`}
        onCanPlay={handleCanPlay}
      />
      {!isCameraReady && !error && (
        <div className="absolute text-slate-400">Starting camera...</div>
      )}
      {isCameraReady && !capturedImage && (
        <button
          onClick={handleCaptureClick}
          className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-6 rounded-full transition duration-300 shadow-lg"
        >
          Capture Photo
        </button>
      )}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};
