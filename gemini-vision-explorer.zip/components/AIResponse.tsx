import React, { useMemo } from 'react';
import { marked } from 'https://esm.sh/marked@^13.0.2';

interface AIResponseProps {
  response: string;
}

export const AIResponse: React.FC<AIResponseProps> = ({ response }) => {
  const parsedHtml = useMemo(() => {
    if (!response) return { __html: '' };
    // Set the sanitized option to true
    const rawMarkup = marked.parse(response, { breaks: true, gfm: true }) as string;
    return { __html: rawMarkup };
  }, [response]);

  return (
    <div 
      className="prose prose-invert prose-slate max-w-none text-slate-300 whitespace-pre-wrap"
      dangerouslySetInnerHTML={parsedHtml} 
    />
  );
};