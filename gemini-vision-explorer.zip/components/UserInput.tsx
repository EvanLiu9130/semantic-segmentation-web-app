
import React from 'react';

interface UserInputProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  disabled: boolean;
}

export const UserInput: React.FC<UserInputProps> = ({ prompt, setPrompt, onSubmit, isLoading, disabled }) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading && !disabled) {
        onSubmit();
      }
    }
  };
  
  return (
    <div className="flex flex-col gap-2">
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={disabled ? "Capture an image first..." : "e.g., What is this object? Can you identify the main color?"}
        className="w-full h-28 p-3 bg-slate-800 border-2 border-slate-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:outline-none transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={disabled || isLoading}
      />
      <button
        onClick={onSubmit}
        disabled={isLoading || disabled || !prompt.trim()}
        className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {isLoading ? 'Thinking...' : 'Send'}
      </button>
    </div>
  );
};
